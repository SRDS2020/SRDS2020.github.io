网站完全由静态html组成

文件目录结构是扁平化的：
	1、当前目录下存放所有html
	2、img js css fonts assets 文件夹下分别存放对应的资源文件