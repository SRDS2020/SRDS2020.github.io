网站完全由静态html组成

主页对应的html是index.html
其他各个页面分别对应哪个html可以通过直接在文件中打开index.html然后在浏览器里转跳看url

网页版：https://srds2020.github.io
GitHub地址：https://github.com/SRDS2020/SRDS2020.github.io

文件目录结构是扁平化的：
	1、当前目录下存放所有html
	2、img js css fonts assets 文件夹下分别存放对应的资源文件
